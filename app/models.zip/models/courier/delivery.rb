class Courier::Delivery
  include Mongoid::Document
  
  embeds_one :waybill  

  field :delivery_state, :type => String
  
  validates :delivery_state, :as => :delivery_state
  
  class << self
    def delivery_states
      [:ready, :accepted, :cancelled, :arrived_at_pickup, :arrived_at_dropoff, :billed]
    end    
    
    def random_delivery_state
      delivery_states[rand(delivery_states.size)]
    end
    
    def create_random
      delivery = self.new :delivery_state => random_delivery_state
      delivery.booking = Booking.
    end

    def create_from booking, state = :ready
      delivery = self.new :delivery_state => state
      delivery.booking = booking
      delivery
    end
  end
end