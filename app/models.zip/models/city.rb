class City
  def self.available country = 'de'
    ['Berlin', 'Munich']
  end
end